import * as PlanetMapper from '../../../../../src/modules/star-wars/mapper/planet.mapper'

describe('Module Planet Mapper test', () => {
  test('Check defined class', () => {
    expect(PlanetMapper).toBeDefined()
  })
})
