import * as Planet from '../../../../../src/modules/star-wars/dto/planet.dto'

describe('Module Planet interface test', () => {
  test('Check defined class', () => {
    expect(Planet).toBeDefined()
  })
})
